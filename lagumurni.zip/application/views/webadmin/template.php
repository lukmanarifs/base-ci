<?=$this->load->view('webadmin/includes/header');?>

<?=$this->load->view('webadmin/includes/sidebar');?>

<section id="main" class="column col_content">
<?=$this->load->view($main_content);?>
</section>

<?=$this->load->view('webadmin/includes/footer');?>