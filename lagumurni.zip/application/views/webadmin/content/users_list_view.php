<article style="width: 95%;" class="module width_3_quarter">
	<header>
		<h3 class="tabs_involved">Users List</h3>
	</header>

	<div class="tab_container">
		<div class="tab_content" style="margin: 5px 5px 0 5px;">
		<?=$this->load->view($table);?>
		</div><!-- end of #tab1 -->
	</div><!-- end of .tab_container -->
</article><!-- end of content manager article -->