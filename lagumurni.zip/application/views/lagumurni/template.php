<?=$this->load->view('lagumurni/includes/header');?>

<!-- Begin main page -->
<div class="container">
<?=$this->load->view($main_content);?>
</div>
<!-- End main content -->

<?=$this->load->view('lagumurni/includes/footer');?>